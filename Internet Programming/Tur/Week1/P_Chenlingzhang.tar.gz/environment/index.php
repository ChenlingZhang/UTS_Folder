<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>My first page</title>
</head>
<body>
    <h1>Hello World! This is my first web page!!</h1>
    <p>My name is Cindy!</p>
</body>
</html>
